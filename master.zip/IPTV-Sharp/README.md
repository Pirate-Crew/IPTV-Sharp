# IPTV Sharp
Windows GUI version of iptv tool

## Disclaimer
This program is just a demo. DO NOT USE IT FOR PERSONAL purpose

## Usage
 Download a release from: [here](https://github.com/Pirate-Crew/IPTV-Sharp/releases/download/IPTV%23/iptv-1.0.0.rar)<br>
 Extract it somewhere<br>
 Open IPTV Sharp.exe <br>
 Select a server from target selector<br>
 Click on "Attack" (this can take up to 5/10 minutes)<br>
 Take some popcorns<br>
 Check output directory for cracked channel<br>
(When a server doesn't give you any accounts just try another one)<br>


## Credits
This version was coded by: [@Arm4x](https://twitter.com/Arm4x)<br><br>
IPTV/PirateCrew team: [@Arm4x](https://twitter.com/Arm4x) [@Pinperepette](https://twitter.com/Pinperepette) [@Ludo237](https://twitter.com/Ludo237)
